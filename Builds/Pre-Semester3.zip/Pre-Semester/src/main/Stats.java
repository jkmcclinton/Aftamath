package main;

import handlers.GameStateManager;

public class Stats extends GameState {

	public Stats(GameStateManager gsm) {
		super(gsm);
	}
	
	public void handleInput() {}
	public void update(float dt) {}
	public void render() {}
	public void dispose() {}
	public void create() {}

}
