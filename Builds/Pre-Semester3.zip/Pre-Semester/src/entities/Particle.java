package entities;

public class Particle  {

	protected Particle(float x, float y, int w, int h, String ID) {
		// TODO Auto-generated constructor stub
	}

}
